import test from 'node:test';
import assert from 'node:assert/strict';
import handler,{validateUrl,extract} from '../netlify/functions/read-product.mjs';
test('reject foreign hosts, credentials and unsafe protocols',()=>{for(const u of ['http://shopee.com.my/x','https://shopee.com.my.evil.com/x','https://127.0.0.1','https://u:p@shopee.com.my/x'])assert.throws(()=>validateUrl(u));assert.equal(validateUrl('https://s.shopee.com.my/abc').hostname,'s.shopee.com.my')});
test('read product JSON-LD, never related card price',()=>{const p=extract('<script type="application/ld+json">{"@type":"Product","name":"Kipas","description":"USB"}</script><aside>Related item RM9</aside>');assert.equal(p.name,'Kipas');assert.equal(p.description,'USB');assert.equal(p.price,undefined)});
test('generic Shopee title is not a product',()=>assert.equal(extract('<meta property="og:title" content="Shopee Malaysia | Shopping">').name,''));
test('no configured access key fails closed',async()=>{delete process.env.TEST_ACCESS_KEY;assert.equal((await handler(new Request('https://example.com',{method:'POST'}))).status,503)});
test('reject unauthorized requests before fetching',async()=>{process.env.TEST_ACCESS_KEY='test-key-123456789';assert.equal((await handler(new Request('https://example.com',{method:'POST',headers:{'x-test-key':'wrong'}}))).status,401)});
