import { timingSafeEqual } from 'node:crypto';

const allowed = new Set(['s.shopee.com.my', 'shopee.com.my', 'www.shopee.com.my']);
export function validateUrl(value) {
  const u = new URL(value);
  if (u.protocol !== 'https:' || !allowed.has(u.hostname) || u.username || u.password || (u.port && u.port !== '443')) throw new Error('Gunakan pautan HTTPS Shopee Malaysia sahaja.');
  return u;
}
function clean(s) {
  return String(s || '').replace(/<[^>]*>/g, ' ').replace(/&quot;/g, '"').replace(/&#39;|&apos;/g, "'").replace(/&amp;/g, '&').replace(/&lt;/g, '<').replace(/&gt;/g, '>').replace(/\s+/g, ' ').trim();
}
export function extract(html) {
  const meta = {};
  for (const tag of html.match(/<meta\b[^>]*>/gi) || []) {
    const attrs = {};
    for (const m of tag.matchAll(/([\w:-]+)\s*=\s*(["'])(.*?)\2/gs)) attrs[m[1].toLowerCase()] = m[3];
    if (attrs.property || attrs.name) meta[attrs.property || attrs.name] = clean(attrs.content);
  }
  const candidates = [];
  function visit(o) {
    if (!o || typeof o !== 'object') return;
    if (Array.isArray(o)) return o.forEach(visit);
    if ([o['@type']].flat().includes('Product')) candidates.push(o);
    if (o['@graph']) visit(o['@graph']);
    if (o.mainEntity) visit(o.mainEntity);
  }
  for (const m of html.matchAll(/<script\b[^>]*type\s*=\s*["']application\/ld\+json["'][^>]*>([\s\S]*?)<\/script>/gi)) {
    try { visit(JSON.parse(m[1])); } catch {}
  }
  // Never select product cards from related-product lists or arbitrary nested data.
  const product = candidates.length === 1 ? candidates[0] : null;
  const rawName = clean(product?.name || meta['og:title']);
  const name = /^(Shopee|Shopee Malaysia)(\s*[|–-].*)?$/i.test(rawName) ? '' : rawName;
  const description = clean(product?.description || meta['og:description'] || meta.description);
  const imageValue = product?.image;
  const image = typeof imageValue === 'string' ? imageValue : Array.isArray(imageValue) ? imageValue[0] : meta['og:image'];
  const warnings = ['Harga, stok, penilaian dan kesahihan dakwaan penjual belum disahkan.', 'Semak variasi produk sebelum menggunakan spesifikasi.'];
  if (candidates.length > 1) warnings.push('Lebih daripada satu produk berstruktur dikesan; butiran variasi tidak dipilih secara automatik.');
  return {name, description, image: typeof image === 'string' && /^https:\/\//.test(image) ? image : null, source:product ? 'Product JSON-LD' : 'Metadata halaman', warnings};
}
const reply = (data, status=200) => new Response(JSON.stringify(data), {status, headers:{'Content-Type':'application/json; charset=utf-8','Cache-Control':'no-store'}});

export default async function handler(req) {
  if (req.method !== 'POST') return reply({error:'Gunakan POST.'},405);
  const secret = process.env.TEST_ACCESS_KEY;
  if (!secret || secret.length < 16) return reply({error:'Tetapkan TEST_ACCESS_KEY sekurang-kurangnya 16 aksara dalam Netlify, kemudian deploy semula.'},503);
  const entered = req.headers.get('x-test-key') || '';
  const a=Buffer.from(secret), b=Buffer.from(entered);
  if (a.length !== b.length || !timingSafeEqual(a,b)) return reply({error:'Kod akses tidak betul.'},401);
  let original;
  try {
    const body = await req.text();
    if (body.length > 4096) return reply({error:'Permintaan terlalu panjang.'},413);
    original = JSON.parse(body).url;
    validateUrl(original);
  } catch { return reply({error:'Masukkan pautan HTTPS Shopee Malaysia yang sah.'},400); }
  const started=Date.now();
  try {
    let target=validateUrl(original), response;
    const signal=AbortSignal.timeout(15000);
    for (let i=0;i<6;i++) {
      response=await fetch(target, {redirect:'manual', signal, headers:{'User-Agent':'ShopeeLinkTest/1.0',Accept:'text/html'}});
      if ([301,302,303,307,308].includes(response.status)) {
        const location=response.headers.get('location');
        await response.body?.cancel();
        if (!location) throw new Error('Pautan pengalihan tidak lengkap.');
        target=validateUrl(new URL(location,target).href);
        if(i===5) throw new Error('Terlalu banyak pengalihan pautan.');
      } else break;
    }
    const base={originalUrl:original, finalUrl:target.origin+target.pathname, httpStatus:response.status, checkedAt:new Date().toISOString(),elapsedMs:Date.now()-started,environment:process.env.NETLIFY ? 'Netlify' : 'Ujian setempat'};
    if(!response.ok) {await response.body?.cancel();return reply({...base,status:'blocked',message:'Shopee tidak memberikan halaman produk kepada permintaan pelayan ini.'});}
    if(!response.headers.get('content-type')?.includes('text/html')) {await response.body?.cancel();return reply({...base,status:'incomplete',message:'Respons bukan halaman HTML produk.'});}
    const reader=response.body.getReader();let size=0;const chunks=[];
    while(true){const {done,value}=await reader.read();if(done)break;size+=value.length;if(size>2_000_000){await reader.cancel();throw new Error('Halaman melebihi had bacaan 2 MB.');}chunks.push(Buffer.from(value));}
    const html=Buffer.concat(chunks).toString('utf8');
    const info=extract(html);
    const productPath=/\/product\/\d+\/\d+|\-i\.\d+\.\d+/.test(target.pathname);
    const status=productPath && info.name && info.description ? 'readable' : 'incomplete';
    return reply({...base,...info,status,message:status==='readable'?'Nama dan penerangan dikesan. Sahkan bahawa kedua-duanya merujuk kepada produk yang betul.':'Maklumat belum mencukupi. Halaman mungkin memerlukan JavaScript, log masuk atau semakan akses.',elapsedMs:Date.now()-started});
  } catch (e) {
    return reply({status:'failed',originalUrl:original,message:e.name==='TimeoutError'?'Shopee tidak memberi respons dalam 15 saat.':e.message,environment:process.env.NETLIFY?'Netlify':'Ujian setempat',elapsedMs:Date.now()-started});
  }
}
