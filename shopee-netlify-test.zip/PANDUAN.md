# Ujian pembacaan Shopee di Netlify

Projek ini belum diterbitkan. Ia menguji permintaan HTML dari pelayan, bukan pelayar automatik. Tiada OpenAI API, tiada bayaran AI dan tiada penerbitan ke Threads.

## Pilihan pemasangan: GitHub + Netlify

1. Cipta repositori GitHub peribadi dan muat naik kandungan folder ini. Pastikan netlify.toml berada di peringkat paling atas.
2. Dalam Netlify, tambah projek dengan mengimport repositori tersebut.
3. Gunakan publish directory `public` dan functions directory `netlify/functions`. Build command boleh dikosongkan.
4. Tambah environment variable bernama `TEST_ACCESS_KEY`. Isikan kod rawak peribadi sekurang-kurangnya 16 aksara. Pastikan tersedia kepada Functions dalam konteks production. Jangan letakkan kod ini dalam fail projek atau hantar melalui chat.
5. Deploy. Jika kod akses ditambah selepas deploy pertama, deploy semula.
6. Buka alamat projek, masukkan kod akses dan pilih salah satu contoh pautan.
7. Semak nama serta penerangan dengan halaman Shopee sebenar. Simpan laporan JSON untuk dikongsi jika perlu.

## Pilihan tanpa GitHub: Netlify CLI

Dengan Node.js 22 atau lebih baharu, buka terminal dalam folder projek ini:

```powershell
npx netlify-cli login
npx netlify-cli deploy --prod --no-build --dir public --functions netlify/functions
```

Pilih cipta projek baharu, bukan projek sedia ada. Kemudian tetapkan TEST_ACCESS_KEY dalam dashboard Netlify dan jalankan arahan deploy sekali lagi. CLI akan meminta anda memberi akses kepada akaun Netlify melalui pelayar.

Jangan hanya drag-and-drop folder public ke Netlify Drop: ujian ini memerlukan fungsi pelayan turut diterbitkan.

## Apa yang dilindungi

Rupa halaman adalah awam jika tetapan Netlify tidak menghadkannya. Pembacaan produk memerlukan kod akses dan gagal jika kod belum ditetapkan. Kod tidak disimpan dalam pelayar. Projek tidak menyimpan laporan atau URL produk dalam pangkalan data, tetapi Netlify masih boleh merekod metadata operasi biasa. Laporan yang dimuat turun mengandungi pautan affiliate asal.

## Tafsiran keputusan

- DATA DIKESAN: nama dan penerangan dikesan pada URL produk. Semakan manual masih diperlukan.
- DATA TIDAK LENGKAP: HTML tidak mengandungi maklumat mencukupi; mungkin memerlukan JavaScript atau log masuk.
- AKSES TIDAK BERJAYA: pelayan Shopee menolak permintaan.
- UJIAN TIDAK BERJAYA: tamat masa, pengalihan tidak disokong atau masalah rangkaian.

Pembaca hanya mengambil Product JSON-LD atau metadata. Ia sengaja tidak mengambil harga, stok atau maklumat kad produk berkaitan. URL gambar sahaja dilaporkan; fail gambar tidak dimuat turun. Halaman yang memerlukan JavaScript mungkin gagal walaupun boleh dibaca melalui pelayar. Ini ialah hasil ujian yang berguna, bukan alasan untuk memintas sekatan.

## Pemeriksaan setempat

`npm test` menguji pengesahan URL, pengasingan maklumat produk dan kawalan akses. Ia tidak membuktikan Shopee boleh dibaca dari Netlify.
